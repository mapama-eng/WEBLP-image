import {
  BenefitFooter,
  ContactStrip,
  FaqPanel,
  FirstView,
  FlowPanel,
  Header,
  PricingPanel,
  ReasonPanel,
  ServicePanel,
  WorkPanel,
  WorryPanel,
} from "./components.jsx";
import { useEffect } from "react";
import initScrollAnimations from "./animations.js";

export default function App() {
  useEffect(() => initScrollAnimations(), []);

  return (
    <div className="lp-shell">
      <Header />
      <main>
        <FirstView />
        <WorryPanel />
        <ServicePanel />
        <ReasonPanel />
        <WorkPanel />
        <PricingPanel />
        <FlowPanel />
        <FaqPanel />
        <ContactStrip />
      </main>
      <BenefitFooter />
    </div>
  );
}
