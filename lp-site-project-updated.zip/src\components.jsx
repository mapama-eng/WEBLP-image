const assetPath = "/assets/";

const links = {
  line: "https://line.me/R/ti/p/@lumiere-lp",
  tel: "tel:0312345678",
  instagram: "https://www.instagram.com/",
  map: "https://www.google.com/maps?q=Tokyo%20Station&output=embed",
};

const navItems = [
  { label: "悩み", href: "#worries" },
  { label: "サービス", href: "#service" },
  { label: "理由", href: "#reasons" },
  { label: "実績", href: "#works" },
  { label: "料金", href: "#pricing" },
  { label: "流れ", href: "#flow" },
  { label: "FAQ", href: "#faq" },
];

const worries = [
  "デザインはきれいなのに、問い合わせや予約につながらない",
  "大人女性向けの上品な世界観をWebでうまく表現できない",
  "美容サロンや女性向けサービスの魅力が、スマホで伝わりにくい",
];

const services = [
  {
    title: "女性向けLP制作",
    text: "30代〜40代の女性が安心して読み進められる、落ち着いた余白と丁寧な導線のLPを制作します。",
  },
  {
    title: "美容サロンLP制作",
    text: "メニュー、料金、スタッフ、予約ボタン、Google Mapまで整理し、初めての方にもわかりやすいページにします。",
  },
  {
    title: "大人女性向けWebサイト設計",
    text: "安さではなく、信頼感・美しさ・丁寧さで選ばれるための文章とビジュアルを整えます。",
  },
];

const reasons = [
  {
    number: "01",
    title: "予約につながるLP導線",
    text: "LINE、電話、フォーム、Instagramへの導線を、スマホで押しやすい位置に配置します。",
  },
  {
    number: "02",
    title: "上品なLPデザイン",
    text: "白を基調にピンクゴールドをアクセントとして使い、派手すぎない華やかさを演出します。",
  },
  {
    number: "03",
    title: "自然なSEO文章",
    text: "検索キーワードを無理に詰め込まず、読んだ女性が安心できる自然な言葉で構成します。",
  },
];

const works = [
  {
    title: "美容サロン向けLPイメージ",
    text: "写真を大きく使い、メニューや料金を見やすく整理。初回予約まで迷わない構成です。",
    image: "hero-urban-rose-gold.png",
  },
  {
    title: "講座・個人ブランド向けLPイメージ",
    text: "プロフィール、実績、サービス内容を丁寧に見せ、問い合わせ前の不安を減らします。",
    image: "cta-rose-tray.png",
  },
];

const prices = [
  {
    plan: "Light",
    price: "¥150,000〜",
    lead: "まずはLPを公開したい方向け",
    items: ["スマホ最適化", "ファーストビュー設計", "LINE問い合わせボタン", "Google Map設置"],
  },
  {
    plan: "Brand",
    price: "¥280,000〜",
    lead: "世界観と予約導線まで整えたい方向け",
    items: ["構成・コピー設計", "サービス内容整理", "料金表・FAQ", "OGP/SEO基本設定"],
    featured: true,
  },
  {
    plan: "Premium",
    price: "¥450,000〜",
    lead: "実績・採用・PRまで含めたい方向け",
    items: ["制作実績セクション", "撮影トーン設計", "構造化データ", "公開後30日改善サポート"],
  },
];

const flow = [
  { title: "無料相談", text: "現在のサービス内容、理想のお客様、予約導線の課題を丁寧に伺います。" },
  { title: "構成・コピー設計", text: "検索されたいキーワードを踏まえながら、自然で読みやすい文章に整えます。" },
  { title: "デザイン・実装", text: "React + Tailwind CSSで、スマホ優先の軽量な静的サイトとして制作します。" },
  { title: "公開・改善", text: "Vercel公開に対応したdistを出力し、公開後の改善ポイントも確認します。" },
];

const faqs = [
  {
    q: "女性向けLP制作でSEO対策もできますか？",
    a: "はい。titleタグ、meta description、OGP、Twitterカード、構造化データ、見出し階層、画像altまで基本SEOを整えます。",
  },
  {
    q: "美容サロンの予約導線も入れられますか？",
    a: "LINE問い合わせ、電話タップ発信、Instagramリンク、Google Map、料金表、メニュー表を自然に配置できます。",
  },
  {
    q: "スマホ表示を最優先にできますか？",
    a: "はい。30代〜40代の女性が片手で読みやすい文字サイズ、余白、ボタンサイズを基準にします。",
  },
];

export function Header() {
  return (
    <>
      <header className="site-header fade-in" data-animate>
        <a className="brand" href="#top" aria-label="Mayumi Watanabe LP Studio">
          <img className="brand-logo" src={`${assetPath}mayumi-watanabe-logo.png`} alt="Mayumi Watanabe LP Studio ロゴ" />
        </a>
        <nav className="desktop-nav" aria-label="主要ナビゲーション">
          {navItems.map((item) => (
            <a key={item.href} href={item.href}>{item.label}</a>
          ))}
        </nav>
        <a className="header-line" href={links.line} target="_blank" rel="noreferrer">無料で相談する</a>
      </header>
      <div className="mobile-sticky-cta" aria-label="スマホ固定問い合わせ導線">
        <a className="sticky-line" href={links.line} target="_blank" rel="noreferrer">LINEで問い合わせる</a>
        <a className="sticky-phone" href={links.tel}>電話する</a>
      </div>
    </>
  );
}

export function FirstView() {
  return (
    <section id="top" className="opening-movie" aria-label="ファーストビュー">
      <div className="opening-photo fade-in" data-animate>
        <img
          src={`${assetPath}hero-urban-rose-gold.png`}
          alt="上品な女性向けLP制作をイメージした白基調のデスクとノートパソコン"
          fetchPriority="high"
        />
      </div>
      <div className="opening-copy fade-in-up" data-animate>
        <p className="eyebrow">Women-focused LP Design</p>
        <h1>女性向けLP制作で、予約につながる上品なWebサイトへ。</h1>
        <p>
          30代〜40代の女性に選ばれる、美しく丁寧なLPサイトを制作します。
          美容サロン、講座、個人ブランドなど、大人女性向けWebサイトに必要な信頼感と予約導線を整えます。
        </p>
        <div className="hero-actions">
          <a className="primary-button" href={links.line} target="_blank" rel="noreferrer">無料で相談する</a>
          <a className="secondary-button" href="#service">制作について相談する</a>
        </div>
      </div>
      <div className="scroll-cue" aria-hidden="true">SCROLL</div>
    </section>
  );
}

export function WorryPanel() {
  return (
    <section id="worries" className="section-shell scroll-reveal" data-animate>
      <SectionHeader
        kicker="Worries"
        title="こんなお悩みはありませんか？"
        text="女性向けサービスでは、価格の安さよりも「信頼できそう」「丁寧に見てくれそう」という印象が問い合わせにつながります。"
      />
      <div className="worry-list reveal-stagger" data-animate>
        {worries.map((item) => (
          <article className="worry-card" key={item}>
            <h3>{item}</h3>
          </article>
        ))}
      </div>
    </section>
  );
}

export function ServicePanel() {
  return (
    <section id="service" className="service-section scroll-reveal" data-animate>
      <div className="section-shell service-inner">
        <SectionHeader
          kicker="Service"
          title="女性向けサービスの問い合わせ・予約を増やすLP制作"
          text="検索で見つけてもらい、スマホで読みやすく、最後は自然に問い合わせできる構成へ整えます。"
        />
        <div className="concept-grid reveal-stagger" data-animate>
          {services.map((item) => (
            <article className="concept-card" key={item.title}>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export function ReasonPanel() {
  return (
    <section id="reasons" className="section-shell airy-section scroll-reveal" data-animate>
      <SectionHeader
        kicker="Reasons"
        title="上品さと成果導線を両立する、選ばれる理由"
        text="白を基調にした余白、ピンクゴールドのアクセント、自然なSEO文章で、安心して問い合わせできるLPにします。"
      />
      <div className="concept-grid reveal-stagger" data-animate>
        {reasons.map((item) => (
          <article className="concept-card" key={item.title}>
            <span>{item.number}</span>
            <h3>{item.title}</h3>
            <p>{item.text}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

export function WorkPanel() {
  return (
    <section id="works" className="section-shell works-section scroll-reveal" data-animate>
      <SectionHeader
        kicker="Works / Image"
        title="制作実績・デザインイメージ"
        text="大きな写真を使い、上品なLPデザインと予約につながる導線を同時に伝えます。"
      />
      <div className="work-grid">
        {works.map((item) => (
          <article className="work-card" key={item.title}>
            <img src={`${assetPath}${item.image}`} alt={item.title} loading="lazy" />
            <div>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export function PricingPanel() {
  return (
    <section id="pricing" className="section-shell scroll-reveal" data-animate>
      <SectionHeader
        kicker="Price"
        title="料金プラン"
        text="女性向けLP制作、美容サロンLP制作、大人女性向けWebサイト設計まで、目的に合わせて選べます。"
      />
      <div className="price-grid">
        {prices.map((plan) => (
          <article className={`pricing-card ${plan.featured ? "featured" : ""}`} key={plan.plan}>
            {plan.featured && <p className="badge">おすすめ</p>}
            <h3>{plan.plan}</h3>
            <p className="plan-best">{plan.lead}</p>
            <strong>{plan.price}</strong>
            <ul>
              {plan.items.map((item) => <li key={item}>{item}</li>)}
            </ul>
            <a href={links.line} target="_blank" rel="noreferrer">制作について相談する</a>
          </article>
        ))}
      </div>
    </section>
  );
}

export function FlowPanel() {
  return (
    <section id="flow" className="section-shell scroll-reveal" data-animate>
      <SectionHeader
        kicker="Flow"
        title="制作の流れ"
        text="初めてLPを作る方でも安心できるように、相談から公開まで丁寧に進めます。"
      />
      <div className="flow-list">
        {flow.map((item, index) => (
          <article className="menu-row" key={item.title}>
            <div>
              <p className="step-label">Step {index + 1}</p>
              <h3>{item.title}</h3>
              <p>{item.text}</p>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export function FaqPanel() {
  return (
    <section id="faq" className="section-shell staff-section scroll-reveal" data-animate>
      <SectionHeader
        kicker="FAQ"
        title="よくある質問"
        text="SEO対策や予約導線、スマホ表示について、事前によくいただく質問をまとめました。"
      />
      <div className="faq-box">
        {faqs.map((faq) => (
          <details key={faq.q}>
            <summary>{faq.q}</summary>
            <p>{faq.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}

export function ContactStrip() {
  return (
    <section id="access" className="access-section scroll-reveal" data-animate>
      <div className="access-copy">
        <p className="eyebrow">Contact</p>
        <h2>女性向けサービスのLP制作を、無料で相談してみませんか？</h2>
        <p>
          今のWebサイトやInstagramを拝見しながら、予約につながるLPに必要な構成、文章、導線を一緒に整理します。
        </p>
        <div className="contact-buttons">
          <a className="primary-button" href={links.line} target="_blank" rel="noreferrer">無料で相談する</a>
          <a className="secondary-button" href={links.line} target="_blank" rel="noreferrer">LINEで問い合わせる</a>
          <a className="text-link" href={links.instagram} target="_blank" rel="noreferrer">Instagramを見る</a>
        </div>
        <form className="contact-form" aria-label="お問い合わせフォーム">
          <input aria-label="お名前" name="name" placeholder="お名前" />
          <input aria-label="メールアドレス" name="email" type="email" placeholder="メールアドレス" />
          <textarea aria-label="お問い合わせ内容" name="message" rows="4" placeholder="お問い合わせ内容" />
          <button type="button">制作について相談する</button>
        </form>
      </div>
      <div className="map-card">
        <iframe title="Google Map" src={links.map} loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
      </div>
    </section>
  );
}

export function BenefitFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-brand">
        <img src={`${assetPath}mayumi-watanabe-logo.png`} alt="Mayumi Watanabe LP Studio ロゴ" loading="lazy" />
        <small>女性向けLP制作 / 美容サロンLP制作 / 大人女性向けWebサイト設計</small>
      </div>
      <a href="#top">ページ上部へ</a>
    </footer>
  );
}

function SectionHeader({ kicker, title, text }) {
  return (
    <header className="section-header">
      <p className="eyebrow">{kicker}</p>
      <h2>{title}</h2>
      {text && <p>{text}</p>}
    </header>
  );
}
